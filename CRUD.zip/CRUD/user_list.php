<?php
$servername = "127.0.0.1";
$username = "root";
$password = "root123";
$dbname = "user_management";

$conn = new mysqli($servername, $username, $password, $dbname,3306);

$sql = "SELECT * FROM users";
$result = $conn->query($sql);

$users = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

echo json_encode($users);

$conn->close();
?>

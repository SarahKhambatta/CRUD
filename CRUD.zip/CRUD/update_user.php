<?php
// Database connection
$servername = "127.0.0.1";
$username = "root";
$password = "root123";
$dbname = "user_management";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Fetch the user data to pre-fill the form
    $sql = "SELECT * FROM users WHERE id = $user_id";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Get the updated data
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];

        // Update the user in the database
        $sql = "UPDATE users SET first_name = '$first_name', last_name = '$last_name', email = '$email' WHERE id = $user_id";
        if ($conn->query($sql) === TRUE) {
            echo "User updated successfully!";
            header("Location: user_list.php"); // Redirect back to the user list page
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
} else {
    echo "User not found.";
}

$conn->close();
?>

<!-- HTML Form for Editing User -->
<form method="POST" action="update_user.php?id=<?php echo $user_id; ?>">
    <input type="text" name="first_name" value="<?php echo $user['first_name']; ?>" required>
    <input type="text" name="last_name" value="<?php echo $user['last_name']; ?>" required>
    <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
    <button type="submit">Update</button>
</form>

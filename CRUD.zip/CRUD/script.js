document.getElementById("registerForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const firstName = document.getElementById("first_name").value;
    const lastName = document.getElementById("last_name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const data = {
        first_name: firstName,
        last_name: lastName,
        email: email,
        password: password
    };

    // Send the registration data to the backend
    fetch("register.php", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("User registered successfully!");
            loadUsers(); // Reload the user list
        } else {
            alert("Error registering user.");
        }
    })
    .catch(error => console.error('Error:', error));
});

// Function to load users from the backend
function loadUsers() {
    fetch("user_list.php")
    .then(response => response.json())
    .then(users => {
        const userList = document.getElementById("userList").getElementsByTagName("tbody")[0];
        userList.innerHTML = ''; // Clear the existing table rows

        users.forEach(user => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${user.first_name}</td>
                <td>${user.last_name}</td>
                <td>${user.email}</td>
                <td>
                    <button class="edit" onclick="editUser(${user.id})">Edit</button>
                    <button class="delete" onclick="deleteUser(${user.id})">Delete</button>
                </td>
            `;
            userList.appendChild(row);
        });
    })
    .catch(error => console.error('Error loading users:', error));
}

// Edit user
function editUser(userId) {
    // Fetch user details and prefill the form
    fetch(`get_user.php?id=${userId}`)
    .then(response => response.json())
    .then(user => {
        document.getElementById("first_name").value = user.first_name;
        document.getElementById("last_name").value = user.last_name;
        document.getElementById("email").value = user.email;
        document.getElementById("password").value = ""; // Don't prefill password for security

        // Update the form to submit for editing
        document.getElementById("registerForm").onsubmit = function(event) {
            event.preventDefault();
            const updatedData = {
                id: userId,
                first_name: document.getElementById("first_name").value,
                last_name: document.getElementById("last_name").value,
                email: document.getElementById("email").value,
                password: document.getElementById("password").value
            };

            // Send the updated data to the backend
            fetch("update_user.php", {
                method: "POST",
                body: JSON.stringify(updatedData),
                headers: {
                    "Content-Type": "application/json"
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("User updated successfully!");
                    loadUsers(); // Reload the user list
                    document.getElementById("registerForm").reset(); // Reset form
                } else {
                    alert("Error updating user.");
                }
            })
            .catch(error => console.error('Error:', error));
        };
    })
    .catch(error => console.error('Error fetching user:', error));
}

// Delete user
function deleteUser(userId) {
    if (confirm("Are you sure you want to delete this user?")) {
        fetch(`delete_user.php?id=${userId}`, {
            method: "DELETE"
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("User deleted successfully!");
                loadUsers(); // Reload the user list
            } else {
                alert("Error deleting user.");
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

// Load users when the page loads
document.addEventListener("DOMContentLoaded", loadUsers);

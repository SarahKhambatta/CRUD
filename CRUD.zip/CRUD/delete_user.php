<?php
$servername = "127.0.0.1";
$username = "root";
$password = "root123";
$dbname = "user_management";

$conn = new mysqli($servername, $username, $password, $dbname,3306);

if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    $sql = "DELETE FROM users WHERE id = $userId";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => $conn->error]);
    }
}

$conn->close();
?>

<?php
$servername = "127.0.0.1";
$username = "root";
$password = "root123";
$dbname = "user_management";

$conn = new mysqli($servername, $username, $password, $dbname,3306);

if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    $sql = "SELECT * FROM users WHERE id = $userId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo json_encode($user);
    } else {
        echo json_encode([]);
    }
}

$conn->close();
?>
